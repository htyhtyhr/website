class Card{

	constructor(suit, value, hidden = false){
		this.suit = suit;
		this.value = value;
		this.hidden = hidden;
	}

}
