# Javascript Roulette
Fully functioning roulette game made in Javascript and CSS

Simply open index.html in your browser and play.

You can edit the files as you wish and use it for any project (commercial or private), some form of attribution would be appreciated, it doesn't have to be a link directly on the page; you could just leave in the author meta tag in the index file and add yourself to it if you make any changes.

Enjoy.

![roulette](https://user-images.githubusercontent.com/95859352/151274580-ca557cac-3c14-4117-ade0-88735f3eeea0.png)
